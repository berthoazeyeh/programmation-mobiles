package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.calculator.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    private ActivityMainBinding binding;
    String ancienNombre="";
    String op="+";
    boolean nouveauop=true;
    boolean boolAfterEq=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

            setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);

    }

    public void editEventButton(View view) {
        if(nouveauop){
            ed1.setText("");
        }
        if(boolAfterEq){
            ed1.setText("");
        }
        String nombre= ed1.getText().toString();

        nouveauop=false;
        boolAfterEq=false;
        switch (view.getId()){
            case  R.id.butZero:
                nombre +="0";
                break;
            case  R.id.butOne:
                nombre +="1";
                break;
            case  R.id.butTow:
                nombre +="2";
                break;
            case  R.id.butThre:
                nombre +="3";
                break;
            case  R.id.butFor:
                nombre +="4";
                break;
            case  R.id.butFive:
                nombre +="5";
                break;
            case  R.id.butSix:
                nombre +="6";
                break;
            case  R.id.butSev:
                nombre +="7";
                break;
            case  R.id.butHuit:
                nombre +="8";
                break;
            case  R.id.butNeuf:
                nombre +="9";
                break;
        }
        ed1.setText(nombre);

    }



    public void EditOnButton(View view) {
    }

    public void deleteEvent(View view) {

//        boolAfterEq=false;
        ed1.setText("0");
        nouveauop=true;
    }

    public void operateurEventButton(View view) {
        nouveauop=true;
        ancienNombre=ed1.getText().toString();
        switch (view.getId()){
            case R.id.butMt:op ="*"; break;
            case R.id.butPlus:op ="+"; break;
            case R.id.butMoin:op ="-"; break;
            case R.id.butBdiv:op ="/"; break;
        }
    }

    public void equalEventButton(View view) {

        String nouveauNombre=ed1.getText().toString();
        double resultat =0.0;
        double n1=0.0;
        double n2=0.0;
        if(ancienNombre.length()>0){
            n1=Double.parseDouble(ancienNombre);
        }
        if(nouveauNombre.length()>0){
            n2=Double.parseDouble(nouveauNombre);
        }
        switch (op){
            case "+":
                resultat=n1 + n2;
                break;
            case "-":
                resultat=n1 - n2;
                break;
            case "*":
                resultat=n1 * n2;
                break;
            case "/":
                resultat=n1 / n2;
                break;
        }
        ed1.setText(resultat+"");
        boolAfterEq=true;
    }
}